        const express = require('express');
        const Product = require('../models/Product');
        const router = express.Router();

// GET /api/products
        router.get('/', async (req, res) => {
          const { q, category, sort, page = 1, limit = 20 } = req.query;
          const filter = {};
          if (q) filter.title = { $regex: q, $options: 'i' };
          if (category) filter.category = category;
          const products = await Product.find(filter)
            .sort(sort === 'price_asc' ? { price: 1 } : { createdAt: -1 })
            .limit(Number(limit))
            .skip((page - 1) * limit);
          res.json(products);
        });

// GET /api/products/:id
        router.get('/:id', async (req, res) => {
          try {
            const p = await Product.findById(req.params.id);
            if (!p) return res.status(404).json({ message: 'Not found' });
            res.json(p);
          } catch (e) {
            res.status(400).json({ message: 'Invalid id' });
          }
        });

module.exports = router;
