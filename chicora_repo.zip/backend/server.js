        const express = require('express');
        const mongoose = require('mongoose');
        const cors = require('cors');
        require('dotenv').config();

const productRoutes = require('./routes/products');

const app = express();
        app.use(cors());
        app.use(express.json());

app.use('/api/products', productRoutes);

const M = process.env.MONGO_URI || 'mongodb://localhost:27017/chicora';
        mongoose.connect(M).then(()=> console.log('MongoDB connected')).catch(e=> console.error(e));
        const port = process.env.PORT || 5000;
        app.listen(port, ()=> console.log(`Server running on ${port}`));
