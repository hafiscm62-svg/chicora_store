// Minimal seed for products
const mongoose = require('mongoose');
const Product = require('../models/Product');
require('dotenv').config();

const M = process.env.MONGO_URI || 'mongodb://localhost:27017/chicora';
mongoose.connect(M).then(()=> console.log('Mongo connected')).catch(e=> console.error(e));

async function seed(){
  await Product.deleteMany({});
  const items = [];
  for(let i=1;i<=12;i++){
    items.push({
      title: `Sample Product ${i}`,
      slug: `sample-product-${i}`,
      description: 'This is a sample product for Chicora.',
      images: ['/placeholder.png'],
      price: Math.floor(Math.random()*2000)+500,
      brand: 'Chicora Brand',
      category: i%2? 'Men':'Women',
      sizes: ['S','M','L'],
      colors: ['Black','White'],
      rating: (Math.random()*2+3).toFixed(1),
      stock: Math.floor(Math.random()*50)+1
    });
  }
  await Product.insertMany(items);
  console.log('Seed complete');
  process.exit(0);
}
seed();
