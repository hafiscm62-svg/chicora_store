export default function ProductCard({ product }){
  return (
    <article style={{border:'1px solid #e5e7eb',padding:12,borderRadius:8}}>
      <img src={product.images?.[0] || '/placeholder.png'} alt={product.title} style={{width:'100%',height:140,objectFit:'cover',borderRadius:6}} />
      <h3 style={{marginTop:8}}>{product.title}</h3>
      <p>₹{product.price}</p>
    </article>
  );
}
