import { useEffect, useState } from 'react';
import ProductCard from '../components/ProductCard';
export default function Home(){
  const [products, setProducts] = useState([]);
  useEffect(()=>{ fetch('/api/products').then(r=>r.json()).then(setProducts).catch(()=>{}); },[]);
  return (
    <main style={{padding:20,fontFamily:'Arial'}}>
      <h1>Chicora — Shop</h1>
      <section style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',gap:16,marginTop:16}}>
        {products.map(p=> <ProductCard key={p._id} product={p} />)}
      </section>
    </main>
  );
}
