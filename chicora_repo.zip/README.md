# Chicora — Fullstack Starter

Minimal starter repo for **Chicora** (Next.js frontend + Express backend).

## Structure
- frontend/  — Next.js app (dev on port 3000)
- backend/   — Express API (dev on port 5000)

## Quick notes
- Run backend: `cd backend && npm install && npm run dev`
- Run frontend: `cd frontend && npm install && npm run dev`
- Use `.env` in backend (see .env.example)
